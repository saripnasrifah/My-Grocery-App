import 'package:flutter/material.dart';
import 'package:my_grocery_app/app_drawer.dart';

class Info extends StatefulWidget {
  const Info({super.key});

  @override
  State<Info> createState() => _InfoState();
}

class _InfoState extends State<Info> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Who We Are',
          style: TextStyle(color: Colors.black),
        ),
        backgroundColor: Colors.white,
        elevation: 2,
        iconTheme: const IconThemeData(color: Colors.black),
        actions: [
          IconButton(
            onPressed: () {},
            icon: const Icon(Icons.add_shopping_cart),
          ),
        ],
      ),
      drawer: const AppDrawer(),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // 🔹 Header
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: const BoxDecoration(
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey,
                    blurRadius: 5,
                    offset: Offset(0, 4),
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'About Us',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: const Text('< Back'),
                  ),
                ],
              ),
            ),

            // 🔹 Body content
            Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // App logo or banner image
                  ClipRRect(
                    borderRadius: BorderRadius.circular(16),
                    child: Image.asset(
                      'lib/images/shoe.jpg',
                      height: 150,
                      fit: BoxFit.contain,
                    ),
                  ),
                  const SizedBox(height: 24),

                  const Text(
                    'Welcome to My Shoe Shop',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.blueAccent,
                    ),
                  ),
                  const SizedBox(height: 16),

                  const Text(
                    'Welcome to SoleStride — your trusted online shoe shop dedicated to bringing you '
                    'the latest trends in quality footwear at affordable prices. Whether you’re looking '
                    'for casual sneakers, formal shoes, or comfortable sandals, SoleStride has something for everyone.\n\n'
                    'Our mission is to make stylish and comfortable shoes accessible to every Filipino, '
                    'while supporting local brands and promoting confidence with every step.\n\n'
                    'This application was developed by students of Northern Mindanao Colleges, Inc., '
                    'as part of our commitment to innovation and digital entrepreneurship.\n\n',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 16, height: 1.5),
                  ),
                  const SizedBox(height: 16),

                  const Divider(thickness: 1.5),
                  const SizedBox(height: 12),

                  const Text(
                    'Developed by:',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                  ),
                  const SizedBox(height: 8), // ✅ FIXED HERE

                  const Text(
                    'Sarip, Nasrifah H.\nNorthern Mindanao Colleges, Inc.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 16),
                  ),
                  const SizedBox(height: 24),

                  const Text(
                    'For inquiries or collaborations, contact us at:📧 nasrifah.saripnormi.edu.ph'
                    '© 2025 Agusan Tourism System.\n All rights reserved.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.grey, fontSize: 14),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
