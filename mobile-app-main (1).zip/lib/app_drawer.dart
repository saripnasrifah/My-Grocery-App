import 'package:flutter/material.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  //store

  @override
  Widget build(BuildContext context) {
    final List<String> news = [
      '👟 Sneaker',
      '👞Formal shoe',
      '🥾  Hiking boot',
      '👠  High heel',
      '👡  Sandal',
      '🥿  Flat shoe',
      '👢 Boot',
    ];

    return Drawer(
      child: ListView(
        children: [
          ListTile(
            title: Text('Shop'),
            onTap: () {
              Navigator.pushNamed(context, '/shop');
            },
          ),
          ListTile(
            title: Text('Newsstand'),
            onTap: () {
              Navigator.pushNamed(
                context,
                '/newsstand',
                arguments: {'news': news},
              );
            },
          ),
          ListTile(
            title: Text('Who we are'),
            onTap: () {
              Navigator.pushNamed(context, '/info');
            },
          ),
          ListTile(
              title: Text('My Profile'),
              onTap: () {
                Navigator.pushNamed(context, '/myprofile');
              }),
          ListTile(
              title: Text('My favorite'),
              onTap: () {
                Navigator.pushNamed(context, '/myfavorite');
              }),
          ListTile(
            title: Text('Basket'),
            onTap: () {
              Navigator.pushNamed(context, '/cart');
            },
          ),
        ],
      ),
    );
  }
}
