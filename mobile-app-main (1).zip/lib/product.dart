class Product {
  final String id;
  final String name;
  final String vendor;
  final double price;

  Product({
    required this.id,
    required this.name,
    required this.vendor,
    required this.price,
  });

  // ✅ Convert Product to a Map (for Firebase or local storage)
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'vendor': vendor,
      'price': price,
    };
  }

  // ✅ Create Product from a Map (e.g., from Firebase or API)
  factory Product.fromMap(Map<String, dynamic> map) {
    return Product(
      id: map['id'] ?? '',
      name: map['name'] ?? '',
      vendor: map['vendor'] ?? '',
      price: (map['price'] ?? 0).toDouble(),
    );
  }

  // ✅ Helpful: convert to JSON
  String toJson() => toMap().toString();

  // ✅ Optional: copyWith method for immutability
  Product copyWith({
    String? id,
    String? name,
    String? vendor,
    double? price,
  }) {
    return Product(
      id: id ?? this.id,
      name: name ?? this.name,
      vendor: vendor ?? this.vendor,
      price: price ?? this.price,
    );
  }
}
