import 'package:flutter/material.dart';
import 'package:my_grocery_app/product.dart';

class CartItem {
  final Product product;
  int quantity;

  CartItem({
    required this.product,
    this.quantity = 1,
  });
}

class CartProvider extends ChangeNotifier {
  final Map<String, CartItem> _items = {};

  Map<String, CartItem> get items => {..._items}; // returns a copy for safety

  int get itemCount => _items.length;

  double get totalAmount {
    return _items.values.fold(
      0.0,
      (sum, item) => sum + (item.product.price * item.quantity),
    );
  }

  // ✅ Add item or increase quantity
  void addItem(Product product) {
    if (_items.containsKey(product.id)) {
      _items.update(
        product.id,
        (existing) => CartItem(
          product: existing.product,
          quantity: existing.quantity + 1,
        ),
      );
    } else {
      _items[product.id] = CartItem(product: product);
    }
    notifyListeners();
  }

  // ✅ Decrease quantity or remove item if zero
  void decreaseItem(String productId) {
    if (!_items.containsKey(productId)) return;

    if (_items[productId]!.quantity > 1) {
      _items.update(
        productId,
        (existing) => CartItem(
          product: existing.product,
          quantity: existing.quantity - 1,
        ),
      );
    } else {
      _items.remove(productId);
    }
    notifyListeners();
  }

  // ✅ Remove entire item from cart
  void removeItem(String productId) {
    _items.remove(productId);
    notifyListeners();
  }

  // ✅ Clear all items
  void clearCart() {
    _items.clear();
    notifyListeners();
  }
}
